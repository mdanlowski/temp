var w = 600;
var h = 600;

function setup() {
 createCanvas(w, h);

}

function draw() {
  background(0, 255, 100);

  if(mouseIsPressed && mouseButton === LEFT){
    strokeWeight(5);
    stroke('red');
    line(pmouseX, pmouseY, mouseX, mouseY);
    // point(mouseX, mouseY);
  }
  if(mouseIsPressed && mouseButton === CENTER){
    strokeWeight(10);
    stroke('green');
    line(pmouseX, pmouseY, mouseX, mouseY);
    // point(mouseX, mouseY);
  }


}


function applySettings(){
  w = document.body.querySelector('form').szerokosc.value;
  h = document.body.querySelector('form').wysokosc.value;
  setup();

}