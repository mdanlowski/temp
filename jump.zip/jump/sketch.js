
// ===========================================================
/// AYY DAT BOUNCY BALL

let initialX = 25;
let initialY = 25;

let speedX = 1;
let speedY = 1;

let i = 2;

function setup() {
   createCanvas(1280, 780);
   textSize(70);

}

function draw() {

  background(0, 255, 100);

  ellipse(initialX, initialY, 50, 50)

  initialX += speedX;
  initialY += (speedY+=1);

  //text(height,500,500,100,100);

  if( (initialY) >= height-15 && (initialY+25) <= height+15 ){ //within range
  	  	// text("ayy\nlmao",500,300,100,300);
  	  	speedY = -speedY;
  	  	speedY += i;
  	  	i++;
  }

}
// ===========================================================