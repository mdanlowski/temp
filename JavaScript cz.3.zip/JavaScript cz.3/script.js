// Zaległe:
// SUBSTRING - w konsoli
// Pętle + wyliczanie elementów tablic
// Funkcje - return, zadanie: 4.d)


// Zasięg zmiennych (Scope)

// jQuerry - podstawowe funkcje
/*
	$(document).ready()
	$(odwołanie).click()
	$(odwołanie).toggleClass()
	$(odwołanie).fadeToggle()
	$(odwołanie).find()
	$(odwołanie).html()		===		stare dobre: document.getElementById("ID").innerHTML()

	API - co to takiego?
	$.getJSON( link, funkcjaPrzetwarzającaWynik( zmiennaPrzechowującaWynik ){} )

/*

[było[	1. Omówienie metody substring i zabawa wyrazami (w nawiązaniu do poprzednich zajęć) - "hello". substring(0, 2). Zadanie: Wypisać pierwsze 3 litery słowa "Batman" i wyłapać słowo "burger" w wyrazie "Hamburger".	]]
[było[	2. Manipulacja danymi w dokumencie za pośrednictwem kodu JS	]]
3. Pętle (for, while) i warunki ich zatrzymywania
4. Funkcje i ich wykorzystanie (wspomnieć o obiektowości)
	a/ Składnia: var nazwaFunkcji = function (parametr) { ... };
	b/ słowo kluczowe "return"
	c/ funkcje z wieloma parametrami np. pole kwadratu
	d/ Zadanie: Stwórz funkcję, która jako parametry będzie przymowała liczbę produktów oraz cenę pojedynczego produktu, a w wyniku wypisze w konsoli wartość całego zamówienia.

5. Zmienne globalne i lokalne.

	var my_number = 7; //this has global scope

	var timesTwo = function(number) {
	var my_number = number * 2;
	console.log("Inside the function my_number is: ");
	console.log(my_number);
	};

	timesTwo(7);

	console.log("Outside the function my_number is: ")
	console.log(my_number);

6. jQuery! - wprowadzenie

*/