//// Metoda document ready wykonuje się dopiero PO załadowaniu dokumentu / elementów HTML.
//// To zarówno "ficzer" ale także i częsty problem dla programistów.
$(document).ready(function () {
    console.log("jQuery załadowane!");

    //// Obsługujemy kliknięcie w każdy tag P na naszej stronie
    $("p").click(function () {
        //// Tutaj wykonujemy nasze akcje, dobierając się do poszczególnych elementów
        //// WAŻNE: this - element kliknięty

        //// Zabawa z toggleClass
        $(this).toggleClass("klikniety");
        // $("p").toggleClass("klikniety");

        //// Wyszukiwanie elementów wewnątrz obecnego elementu (this)
        //// WAŻNE: $(body) / $(document) etc. pozwala szukać wewnątrz całego dokumentu! - jest to
        //// jednak mało wydajne i trzeba na to uważać.
        $(this).find("span").toggleClass("czerwony");

        //// Podmieniamy zawartość elementów wykorzystując metodę .html()
        //console.log($(this).find("span").html());
        // $(this).find("span").html("(HAHAHAHAH!!!)");
        // $(this).find("span").fadeToggle();
    });

    // $("#parag").click(function () {
    //     $(this).toggleClass("czerwony");
    // });


    //// ZABAWY Z API
    var udanaLokalizacja = function (pozycja) {
        console.log("Udało się zlokalizować!");

        //// Wypisujemy cały obiekt z pozycją
        console.log(pozycja);

        //// Wypisujemy szerokość i długość geograficzną
        var lat = pozycja.coords.latitude;
        var lng = pozycja.coords.longitude;

        //// Wyświetlamy obrazek z mapą
        var latlng = lat + "," + lng;
        var imgUrl = "http://maps.googleapis.com/maps/api/staticmap?center=" +
                     latlng + "&zoom=17&size=600x400&sensor=false";
        console.log(imgUrl);

        $("#mapa").html("<img src='" + imgUrl + "'>");

        //// Określenie miasta / ulicy
        var geocodeUrl = "http://maps.googleapis.com/maps/api/geocode/json?latlng=" +
                         latlng + "&sensor=true";
        console.log(geocodeUrl);

        $.getJSON(geocodeUrl, function (result) {
            console.log(result);
            if (result.results.length > 0) {
                var adres = result.results[0].formatted_address;
                console.log(adres);

                $("#adres").html("<h1>" + adres + "</h1>");

                //// Pogoda!!!!!
                //// Dokumentacja: http://developer.yahoo.com/weather/documentation.html
                            // TUTAJ ZNAJDUJE SIĘ KOD W JĘZYKU ZAPYTAŃ SQL, UŻYWANYM DO POBIERANIA OKREŚLONYCH DANYCH Z BAZ DANYCH, 
                            // KTÓRE MOŻNA PORÓWNAĆ DO ARKUSZY PROGRAMU EXCEL:
                var query = "select * from weather.forecast where woeid in " +
                            "(select woeid from geo.places(1) where text='" + adres + "') and u='c'";
                var pogodaUrl = "https://query.yahooapis.com/v1/public/yql?q=" +
                                query + "&format=json";
                console.log(pogodaUrl);
                $.getJSON(pogodaUrl, function (pogodaResult) {
                    //// Sprawdzamy czy w ogóle dostaliśmy odp
                    if (pogodaResult.query.results) {
                        console.log(pogodaResult);

                        //// Wypisujemy wyniki / elementy, które nas interesują tj. wstawiamy je na naszą stronę
                        $("#temp").html("<h1>" + pogodaResult.query.results.channel.item.condition.temp + "&#176; Celsjusza</h1>");
                        $("#pogoda").html(pogodaResult.query.results.channel.item.description);
                    }
                });
            }
        });
    };

    var bladWLokalizacji = function (blad) {
        console.log("Nie udało się zlokalizować :(");
    };

    // TUTAJ SPRAWDZANA JEST LOKALIZACJA
    // Odpowiada za nią komponent przeglądarki navigator i jego element o nazwie geolocation
    if (navigator.geolocation) {
        // Jeżeli odczyt pozycji się powiedzie, wywołana jest funcja o nazwie udanaLokalizacja, natomiast w przypadku niepowodzenia: bladWLokalizacji
        navigator.geolocation.getCurrentPosition(udanaLokalizacja, bladWLokalizacji);
    }
    else {
        alert("Niestety, Twoja przeglądarka nie wspiera geolokalizacji :(((");
    }

});