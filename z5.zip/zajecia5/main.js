// var imie = "Marcin"; // variable
// alert("Siema "+imie);

// var wiek = prompt("ile masz lat?");

var nav1 = function(){
	document.querySelector('main').style.color = 'black';
}
var nav2 = function(){
	document.querySelector('main').style.color = 'red';
}
var nav3 = function(){
	document.querySelector('main').style.color = 'green';
}
var nav4 = function(){
	document.querySelector('main').style.color = 'blue';
}

