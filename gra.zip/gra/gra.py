HEIGHT = 600
WIDTH = 800

krzys = Actor('alien')
krzys.pos = 100, 300
krzys.sx = 10
krzys.sy = 10
die = tone.create("C6", 0.5)
krzys.score = 0

def draw():
    screen.clear()
    krzys.draw()
    screen.draw.text(str(screen.score), [10,10])

def update():
    krzys.x += krzys.sx
    krzys.y += krzys.sy
    if krzys.x + krzys.width/2 >= WIDTH:
        krzys.sx = -1*krzys.sx

    if krzys.y + krzys.height/2 >= HEIGHT:
        krzys.sy = -1*krzys.sy

    if krzys.x - krzys.width/2 <= 0:
        krzys.sx = -1*krzys.sx

    if krzys.y - krzys.height/2 <= 0:
        krzys.sy = -1*krzys.sy


def on_mouse_down(pos):
    if krzys.collidepoint(pos):
        die.play()
        screen.score += 1
    else:
        print("missed!!!!!")





