//BIBLIOTEKA JQUERY

$(document).ready(function(){
    $(".expandable").click(function(){
    	$(this).toggleClass('popdown');
    	$(this).toggleClass('scale-in-ver-top');

   //  	if(czyOtwarta===true){	// to znaczy ze musimy z powrtoem schować kartę
   //  		$(this).removeClass('scale-in-ver-top');
			// $(this).addClass('scale-out-ver-top');
			// czyOtwarta = !czyOtwarta;
   //  	}
   //  	else{					// to znaczy ze możemy wysunąć kartę
   //  		$(this).addClass('scale-in-ver-top');
			// $(this).removeClass('scale-out-ver-top');
			// czyOtwarta = !czyOtwarta;
   //  	}
        
    });
});