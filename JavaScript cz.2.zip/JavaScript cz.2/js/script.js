alert('ayy lmao');

var klik = function() {
	
	var red = document.getElementById('kolor1').value;
	console.log(red);
	// document.getElementsByTagName('body');
}

function x() {

}