// var Ty = prompt("Hej, podaj swoje imię!");
// alert("Cześć " + Ty + " - Witaj na drugich zajęciach z JS!");
// document.getElementsByTagName("div")[3].innerHTML = "UŻYTKOWNIK:<br/>"+Ty;

var przycisk1 = function() {
	var kolor = document.getElementById('kolor1').value;
	console.log(kolor);
	document.getElementsByTagName("body")[0].style.backgroundColor = kolor;
}

var przycisk2 = function() {
	var kolor = document.getElementById('kolor2').value;
	console.log(kolor);
	document.getElementById("zadanie").style.backgroundColor = kolor;
}

var suwaki = function(){
	var red = document.getElementById('suwak1').value;
	var green = document.getElementById('suwak2').value;
	var blue = document.getElementById('suwak3').value;
	var kolor = "rgb(" + red + "," + green + "," + blue + ")";
	console.log(kolor);
	document.getElementsByTagName("div")[2].style.backgroundColor = kolor;
	var rozmiarTekstu = document.getElementById('suwakTekst').value + "px";
	console.log(rozmiarTekstu);
	document.getElementsByTagName("div")[2].style.fontSize = rozmiarTekstu;
}